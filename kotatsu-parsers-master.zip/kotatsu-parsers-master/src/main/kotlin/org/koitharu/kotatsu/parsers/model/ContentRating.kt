package org.koitharu.kotatsu.parsers.model

public enum class ContentRating {
	SAFE,
	SUGGESTIVE,
	ADULT
}
