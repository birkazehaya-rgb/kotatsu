package org.koitharu.kotatsu.parsers.exception

public class ContentUnavailableException(message: String) : RuntimeException(message)
